class vector:
    def __init__(x, y):
        self.x = x
        self.y = y

    def move_to(x, y):
        self.x = x
        self.y = y

    def move_rel(x, y):
        self.x += x
        self.y += y
